﻿using System;
using System.Collections.Generic;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            List<Person> people = new List<Person>();
                      
            var pesho = new Person("Pesho", 20);
            var gosho = new Person("Gosho", 18);
            var stamat = new Person("Stamat", 43);
                      
            
        }
    }
}
