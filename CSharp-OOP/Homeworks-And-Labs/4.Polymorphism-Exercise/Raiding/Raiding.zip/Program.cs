﻿using System;

namespace Raiding
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            int sum = 0;

            for (int i = 0; i < n; i++)
            {
                string playerName = Console.ReadLine();
                string heroType = Console.ReadLine();

                if (heroType == "Druid")
                {
                    BaseHero druid = new Druid( playerName);
                    sum += druid.Power;
                    Console.WriteLine(druid.CastAbility());
                }
                else if(heroType == "Paladin")
                {
                    BaseHero paladin = new Paladin(playerName);
                    sum += paladin.Power;
                    Console.WriteLine(paladin.CastAbility());
                }
                else if (heroType == "Rogue")
                {
                    BaseHero rogue = new Rogue(playerName);
                    sum += rogue.Power;
                    Console.WriteLine(rogue.CastAbility());
                }
                else if(heroType == "Warrior")
                {
                    BaseHero warrior = new Warrior(playerName);
                    sum += warrior.Power;
                    Console.WriteLine(warrior.CastAbility());
                }
                else
                {
                    Console.WriteLine("Invalid hero!");
                    continue;
                }
            }

            int bossPower = int.Parse(Console.ReadLine());

            if (sum >= bossPower)
            {
                Console.WriteLine("Victory!");
            }
            else
            {
                Console.WriteLine("Defeat...");
            }
        }
    }
}
