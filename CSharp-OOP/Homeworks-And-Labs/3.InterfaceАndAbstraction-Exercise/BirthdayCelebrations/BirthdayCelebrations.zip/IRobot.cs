﻿
namespace BirthdayCelebrations
{
    interface IRobot : IIdentifiable
    {
       string Model { get; }
    }
}
