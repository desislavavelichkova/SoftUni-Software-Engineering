﻿
namespace PersonInfo

{
    public interface IBirthable
    {
        string Birthdate { get; }
    }
}
