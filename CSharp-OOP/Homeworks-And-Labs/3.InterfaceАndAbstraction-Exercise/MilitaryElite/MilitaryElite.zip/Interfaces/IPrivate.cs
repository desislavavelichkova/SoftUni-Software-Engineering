﻿
namespace MilitaryElite
{
    public interface IPrivate: ISoldier
    {
        double Salary { get; }
    }
}
