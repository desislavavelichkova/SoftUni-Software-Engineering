﻿
namespace MilitaryElite
{
    public interface IRepair
    {
        string PartName { get; }
        int WorkedHours { get; }
    }
}
