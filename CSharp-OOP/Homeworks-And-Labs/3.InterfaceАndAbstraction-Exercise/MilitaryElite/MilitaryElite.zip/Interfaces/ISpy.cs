﻿
namespace MilitaryElite
{
    public interface ISpy: ISoldier
    {
        int CodeNumber { get;}
    }
}
