﻿using AquaShop.Core.Contracts;
using AquaShop.Models.Aquariums;
using AquaShop.Models.Aquariums.Contracts;
using AquaShop.Models.Decorations;
using AquaShop.Models.Decorations.Contracts;
using AquaShop.Models.Fish;
using AquaShop.Models.Fish.Contracts;
using AquaShop.Repositories;
using AquaShop.Repositories.Contracts;
using AquaShop.Utilities.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AquaShop.Core
{
    public class Controller : IController
    {
        private List<IAquarium> aquariums;
        private DecorationRepository decorations;
        

        public Controller()
        {
            this.aquariums = new List<IAquarium>();
            this.decorations = decorations;

        }

        public string AddAquarium(string aquariumType, string aquariumName)
        {
                             

            if (aquariumType == nameof(FreshwaterAquarium))
            {
                IAquarium aquarium = new FreshwaterAquarium(aquariumName);
                aquariums.Add(aquarium);
            }
            else if (aquariumType == nameof(SaltwaterAquarium))
            {
                IAquarium aquarium = new SaltwaterAquarium(aquariumName);
                aquariums.Add((IAquarium)aquarium);
            }
            else
            {
                throw new InvalidOperationException(string.Format(ExceptionMessages.InvalidAquariumType));
            }           

            return string.Format(OutputMessages.SuccessfullyAdded, aquariumType);
        }

        public string AddDecoration(string decorationType)
        {          

            if (decorationType == nameof(Ornament))
            {
               IDecoration decoration = new Ornament();
                decorations.Add((IDecoration)(DecorationRepository)decoration);
            }
            else if (decorationType == nameof(Plant))
            {
                IDecoration decoration = new Plant();
                decorations.Add((IDecoration)(DecorationRepository)decoration);
            }
            else
            {
                throw new InvalidOperationException(string.Format(ExceptionMessages.InvalidDecorationType));
            }
            
            return string.Format(OutputMessages.SuccessfullyAdded, decorationType);
        }
       
        public string AddFish(string aquariumName, string fishType, string fishName, string fishSpecies, decimal price)
        {
            var currentAquarium = aquariums.FirstOrDefault(x => x.Name == aquariumName);
            
            if (fishSpecies != nameof(FreshwaterAquarium) && fishSpecies != nameof(SaltwaterAquarium))
            {
                return string.Format(OutputMessages.UnsuitableWater);
            }
            if (fishType == nameof(FreshwaterFish))
            {
                var fish = new FreshwaterFish(fishName, fishSpecies, price);
                currentAquarium.AddFish(fish);
            }
            else if (fishType == nameof(SaltwaterFish))
            {
                var fish = new SaltwaterFish(fishName, fishSpecies, price);
                currentAquarium.AddFish(fish);
            }
            else
            {
                throw new InvalidOperationException(ExceptionMessages.InvalidFishType);
            }
            
            return string.Format(OutputMessages.EntityAddedToAquarium, fishType, aquariumName );
        }

        public string CalculateValue(string aquariumName)
        {
            var currentAquarium = aquariums.FirstOrDefault(x => x.Name == aquariumName);

            var sumOfFishes = currentAquarium.Fish.Sum(x => x.Price);
            var sumOfDecorations = currentAquarium.Decorations.Sum(x => x.Price);
            var total = sumOfFishes + sumOfDecorations;

            return string.Format(OutputMessages.AquariumValue, aquariumName, total);
        }

        public string FeedFish(string aquariumName)
        {
            var currentAquarium = aquariums.FirstOrDefault(x => x.Name == aquariumName);
            int quantityOfFishes = 0;

            foreach (var fish in currentAquarium.Fish)
            {
                fish.Eat();
                quantityOfFishes++;
            }            

            return string.Format(OutputMessages.FishFed, quantityOfFishes);

        }

        public string InsertDecoration(string aquariumName, string decorationType)
        {
            var findDecoration = decorations.FindByType(decorationType);
            var currentAquarium = aquariums.FirstOrDefault(x => x.Name == aquariumName);

            if (findDecoration == null)
            {
                throw new InvalidOperationException($"There isn't a decoration of type {decorationType}.");
            }
            else
            {
                decorations.Remove(findDecoration);
                currentAquarium.AddDecoration((IDecoration)findDecoration);
            }
            return string.Format(OutputMessages.EntityAddedToAquarium, decorationType, aquariumName);
        }

        public string Report()
        {
            StringBuilder sb = new StringBuilder();

            foreach (var aquarium in aquariums)
            {
                sb.AppendLine(aquarium.GetInfo());
            }

            return sb.ToString().TrimEnd();
        }
    }
}
