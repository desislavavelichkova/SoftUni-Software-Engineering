﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AquaShop.Models.Fish
{
    public class FreshwaterFish : Fish
    {
        private const int sizeConst = 3;
        private static int size = 3;
        //private string spicies = "FreshwaterAquarium";
        public FreshwaterFish(string name, string species, decimal price)
            : base(name, species, size, price)
        {         
        } 
        public override void Eat()
        {
            size += sizeConst;
        }
        
    }
}
